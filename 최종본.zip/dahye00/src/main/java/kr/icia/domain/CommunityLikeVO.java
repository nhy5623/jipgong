package kr.icia.domain;

import lombok.Data;

@Data
public class CommunityLikeVO {
	private Long community_bno;
	private String user_id;
	private int community_good;
	
	
	
}